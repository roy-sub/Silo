import os
import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from urllib.parse import urljoin, urlparse

CHROME_DRIVER_PATH = '/home/subhrastien/Development/scraper_dev/chromedriver'

class Scraper:
    
    def __init__(self):
        os.chmod(CHROME_DRIVER_PATH,0o755) 
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--headless")
        self.driver = webdriver.Chrome(options=chrome_options)
        
    def get_text(self, webpage_url):
        try:
            self.driver.get(webpage_url)
            body = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            text = body.text
            return text
        except Exception as e:
            print(f"An error occurred while scraping {webpage_url}: {str(e)}")
            return None
        finally:
            self.driver.quit()
    
    def get_all_subpages(self,domain):
        if not domain.startswith(('http://', 'https://')): domain = 'https://' + domain
        parsed_domain = urlparse(domain)
        base_url = f"{parsed_domain.scheme}://{parsed_domain.netloc}"
        all_urls = set()
        to_crawl = [base_url]
        
        try:
            while to_crawl:
                current_url = to_crawl.pop(0)
                
                try:
                    self.driver.get(current_url)
                    WebDriverWait(self.driver, 10).until(
                        EC.presence_of_element_located((By.TAG_NAME, "body"))
                    )
                    
                    # Find all links on the page
                    links = self.driver.find_elements(By.TAG_NAME, "a")
                    
                    for link in links:
                        href = link.get_attribute("href")
                        if href:
                            full_url = urljoin(current_url, href)
                            
                            # Check if the URL belongs to the same domain
                            if urlparse(full_url).netloc == parsed_domain.netloc:
                                if full_url not in all_urls:
                                    all_urls.add(full_url)
                                    to_crawl.append(full_url)
                
                except Exception as e:
                    print(f"Error processing {current_url}: {str(e)}")
        
        finally:
            self.driver.quit()

        all_urls.add(base_url)
        return list(all_urls)

# url = "https://www.krankenhaus.de"
# text = Scraper().get_text(url)
# if text:
#     print(text)
# else:
#     print("Failed to scrape the webpage.")
    
domain = "krankenhaus.de"
subpages =  Scraper().get_all_subpages(domain)
print(f"Found {len(subpages)} subpages:")
for page in subpages:
    print(page)
print(subpages)
