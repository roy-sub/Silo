import re
import csv
import requests
from urllib.parse import quote
from constants import keywords
from io import StringIO

import os
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.output_parsers import StructuredOutputParser, ResponseSchema

def classify_website_type(website_text):
    # Set your OpenAI API key
    os.environ["OPENAI_API_KEY"] = "sk-N4R5j9JLiUarXfHXc_n9cVm1muRiuipx7mTjcq2asnT3BlbkFJIGeMAZ7dAUZKiYpVj_vu9vfgk_F--zCAXw9GOuAMIA"

    # Initialize the language model
    llm = ChatOpenAI(model_name="gpt-3.5-turbo")

    # Define the output schema
    response_schemas = [
        ResponseSchema(name="is_portal", description="Whether the website is a portal/directory (Yes) or a single webpage (No)")
    ]
    output_parser = StructuredOutputParser.from_response_schemas(response_schemas)

    # Create the prompt template
    prompt_template = """
    Analyze the following website text and determine if it's a portal/directory with many companies or a single webpage.

    Website Text:
    {website_text}

    Classify the website as either a portal/directory (Yes) or a single webpage (No).

    {format_instructions}
    """

    # Create the chat prompt
    prompt = ChatPromptTemplate.from_template(template=prompt_template)

    # Generate the messages
    messages = prompt.format_messages(
        website_text=website_text,
        format_instructions=output_parser.get_format_instructions()
    )

    # Get the response from the language model
    response = llm(messages)

    # Parse the response
    parsed_response = output_parser.parse(response.content)

    return parsed_response["is_portal"]


def extract_data(file_path, start, end):
    result = []
    
    with open(file_path, 'r') as csvfile:
        csvreader = csv.DictReader(csvfile)
        
        for index, row in enumerate(csvreader, start=1):
            if start <= index <= end:
                result.append([row['id'], row['web']])
            elif index > end:
                break
    
    return result

def get_page_text(page_link):
    encoded_link = quote(page_link)
    api_url = f"https://ws-ai.app.n8n.cloud/webhook/single_page_website_text?page_link={encoded_link}"
    print(f"Requesting URL: {api_url}")
    
    try:
        response = requests.get(api_url, timeout=30)
        print(f"Response status code: {response.status_code}")
        print(f"Response headers: {response.headers}")
        
        response.raise_for_status()
        
        print(f"Response content (first 100 chars): {response.text[:100]}")
        return response.text
    except requests.RequestException as e:
        print(f"Error fetching text for {page_link}: {e}")
        if hasattr(e, 'response'):
            print(f"Error response status code: {e.response.status_code}")
            print(f"Error response content: {e.response.text}")
        return None
    
def get_all_pages(domain):
    api_url = "https://ws-ai.app.n8n.cloud/webhook/all_pages"
    full_url = f"{api_url}?domain={domain}"
    
    try:
        response = requests.get(full_url)
        response.raise_for_status()
        pages = response.json()
        
        # Create the domain URL
        domain_url = f"https://{domain}"
        
        # Check if the domain URL already exists in the list
        if not any(page['href'] == domain for page in pages):
            print(f"\nbase url not found in the response hence inserting\n")
            pages.insert(0, {'href': domain})
        
        # Ensure all hrefs have the full URL
        for page in pages:
            if not page['href'].startswith('http'):
                page['href'] = f"{domain_url}/{page['href'].lstrip('/')}"
        
        return pages
    except requests.RequestException as e:
        print(f"Error fetching pages for domain {domain}: {e}")
        return None    # Example domain

def search_keywords(keywords, text):
    # Convert text to lowercase for case-insensitive search
    text_lower = text.lower()
    
    # Initialize variables
    contains_keyword = False
    keyword_info = []
    
    for keyword in keywords:
        # Convert keyword to lowercase
        keyword_lower = keyword.lower()
        
        # Count occurrences of the keyword
        count = len(re.findall(r'\b' + re.escape(keyword_lower) + r'\b', text_lower))
        
        if count > 0:
            contains_keyword = True
            keyword_info.append([keyword, count])
    
    return contains_keyword, keyword_info

def update_csv(file_path, index, column, value):
    # Read the entire file into memory
    with open(file_path, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        rows = list(reader)

    # Update the specific row and column
    for row in rows:
        if row['id'] == str(index):
            row[column] = value
            break

    # Write the updated data back to the file
    with open(file_path, 'w', newline='') as csvfile:
        fieldnames = reader.fieldnames
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

def generator(start, end, file_path):
    
    web = extract_data(file_path, start, end)
    print(f"web: {web}\n")
    
    for item in web:
        index = item[0]
        domain = item[1]
        
        homepage_link = f"https://{domain}"
        print(f"homepage_link: {homepage_link}\n")
        
        homepage_text = get_page_text(homepage_link)
        print(f"homepage_text: {homepage_text}\n")
        
        is_portal = classify_website_type(homepage_text)
        print(f"is_portal: {is_portal}\n")
        
        # Update the portal_webpage attribute in the CSV
        update_csv("data/result.csv", index, "portal_webpage", is_portal)
        
        if is_portal == "No":
            
            all_pages_href = get_all_pages(domain)
            print(f"all_pages_href: {all_pages_href}\n")
            
            total_number_of_subpages = len(all_pages_href) - 1
            print(f"total_number_of_subpages: {total_number_of_subpages}\n")
            
            # Update the total_number_of_subpages attribute in the CSV
            update_csv("data/result.csv", index, "total_number_of_subpages", str(total_number_of_subpages))
            
            total_number_of_words = 0
            number_of_subpages_where_keywords_were_found = 0
            how_many_keywords_were_found = 0
            
            for item in all_pages_href:
                
                href = item['href']
                page_link = f"https://{href}"
                print(f"page_link: {page_link}\n")
                
                page_text = get_page_text(page_link)
                print(f"page_text: {page_text}\n")
                
                number_of_words = len(page_text.split())
                print(f"number_of_words: {number_of_words}\n")
                
                total_number_of_words = total_number_of_words + number_of_words
                
                contains_keyword, keyword_info = search_keywords(keywords, page_text)
                
                print(f"contains_keyword: {contains_keyword}\n")
                print(f"keyword_info: {keyword_info}\n")
                
                if contains_keyword:
                    
                    number_of_subpages_where_keywords_were_found = number_of_subpages_where_keywords_were_found+1
                    keyword_count = len(keyword_info)
                    how_many_keywords_were_found = how_many_keywords_were_found + keyword_count
            
            print(f"total_number_of_words: {total_number_of_words}\n")
            print(f"number_of_subpages_where_keywords_were_found: {number_of_subpages_where_keywords_were_found}\n")
            print(f"how_many_keywords_were_found: {how_many_keywords_were_found}\n")
           
            update_csv("data/result.csv", index, "total_number_words", total_number_of_words)
            update_csv("data/result.csv", index, "number_of_subpages_where_keywords_were_found", number_of_subpages_where_keywords_were_found)
            update_csv("data/result.csv", index, "how_many_keywords_were_found", how_many_keywords_were_found)
            
        else:
            update_csv("data/result.csv", index, "portal_webpage", is_portal)
            
# Example Usage

if __name__ == "__main__":
    
    # start = 10
    # end = 11
    # file_path = "data/Database.csv"
    # generator(start, end, file_path)

    page_link = "https://rehapraxohl.de/leistungen"
    
    text = get_page_text(page_link)
    
    if text:
        print("Extracted text:")
        print(text)
    else:
        print("Failed to extract text.")
