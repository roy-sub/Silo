import requests
from urllib.parse import quote

def get_all_pages(domain):
    api_url = f"https://ws-ai.app.n8n.cloud/webhook/all_pages?domain={domain}"
    
    try:
        print("calling")
        response = requests.get(api_url)
        response.raise_for_status()
        pages = response.json()
        
        # Create the domain URL
        domain_url = f"https://{domain}"
        
        # Check if the domain URL already exists in the list
        if not any(page['href'] == domain for page in pages):
            print(f"\nbase url not found in the response hence inserting\n")
            pages.insert(0, {'href': domain})
        
        # Ensure all hrefs have the full URL
        for page in pages:
            if not page['href'].startswith('http'):
                page['href'] = f"{domain_url}/{page['href'].lstrip('/')}"
        
        return pages
    except requests.RequestException as e:
        print(f"Error fetching pages for domain {domain}: {e}")
        return None    # Example domain
    
if __name__ == "__main__":
    domain = "rehapraxohl.de"
    pages = get_all_pages(domain)
    print(pages)
