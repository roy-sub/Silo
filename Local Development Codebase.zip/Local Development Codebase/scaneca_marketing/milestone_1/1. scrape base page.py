import os
import json
from selenium import webdriver
from constants import CHROME_DRIVER_PATH
from selenium.webdriver.common.by import By
from urllib.parse import urlparse

# This script scrapes the text, URL, and domain from a specified webpage
# It extracts information from list items within a specific CSS selector

class GoogleMapsScraper:
  def __init__(self):
    os.chmod(CHROME_DRIVER_PATH,0o755) 
    chrome_options = webdriver.ChromeOptions()
    self.driver = webdriver.Chrome(options=chrome_options)
    self.data = []
  
  def extract_domain(self, url):
    parsed_url = urlparse(url)
    domain = parsed_url.netloc
    # Remove 'www.' if present
    if domain.startswith('www.'):
        domain = domain[4:]
    return domain

  def scrape(self, url):
    
    self.driver.get(url)
    
    li_elements = self.driver.find_elements(By.CSS_SELECTOR, ".aekart ul li")
    
    for li in li_elements:
      try:
        
        url = li.find_element(By.TAG_NAME, "a").get_attribute("href")
        domain = self.extract_domain(url)
        text = li.text.strip()
        
        self.data.append({
            "url": url,
            "domain": domain,
            "full_text": text
        })
      
      except Exception as e:
        print(f"Error processing element: {e}")
    
  def save_to_json(self, filename='data/1. data.json'):
      with open(filename, 'w', encoding='utf-8') as f:
          json.dump(self.data, f, ensure_ascii=False, indent=4)
      print(f"Data saved to {filename}")
  
  def close(self):
      self.driver.quit()

# Usage example:
if __name__ == "__main__":

    url = 'https://www.lipoedemportal.de/lipoedem-liposuktion-spezialisten.htm'
    scraper = GoogleMapsScraper()
    scraper.scrape(url)
    scraper.save_to_json()
    scraper.close()
