import os
import json
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate
from langchain_community.chat_models import ChatOpenAI

# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = ""

# This script processes and structures mailing addresses for marketing purposes:

# - It takes the original text from the base webpage and the previously scraped address
# - Using AI, it analyzes both inputs to create a well-structured mailing address
# - The address is formatted according to the marketing team's requirements
# - Personal names are removed from the address to focus on location information
# - The script processes each entry in the input JSON file and saves the results

class AddressProcessor:
    def __init__(self):
        self.llm = ChatOpenAI(model_name="gpt-4")

    def process_address(self, full_text, address):
        prompt_template = """
        Based on the following information, provide a comprehensive, well-structured address suitable for postal use. The address should only contain location information and details. Do not include any person's name in the address. Do not make up any information that is not present in the given text.

        Full Text: {full_text}
        Current Address: {address}

        Please provide a comprehensive address without any personal names:
        """

        prompt = ChatPromptTemplate(
            messages=[HumanMessagePromptTemplate.from_template(prompt_template)],
            input_variables=["full_text", "address"]
        )

        messages = prompt.format_messages(full_text=full_text, address=address)
        output = self.llm(messages)

        return output.content.strip()

    def process_json_file(self, input_file, output_file):
        with open(input_file, 'r') as f:
            data = json.load(f)
        
        processed_data = []
        total_items = len(data)
        
        for index, item in enumerate(data, start=1):
            print(f"\nProcessing {index}/{total_items}")
            try:
                full_text = item.get('full_text', '')
                current_address = item.get('address', '')
                
                concatenated_input = f"{full_text}\n{current_address}"
                
                processed_address = self.process_address(concatenated_input, current_address)
                print(f"Processed Address: {processed_address}")
                
                item['Address'] = processed_address
                processed_data.append(item)
            except Exception as e:
                print(f"Error processing item: {e}")
                processed_data.append(item)  # Append the original item if processing fails
        
        with open(output_file, 'w') as f:
            json.dump(processed_data, f, indent=2)

if __name__ == "__main__":
    input_file = 'data/4. data.json'
    output_file = 'data/5. data.json'
    processor = AddressProcessor()
    processor.process_json_file(input_file, output_file)
    print(f"Processed data has been saved to {output_file}")
