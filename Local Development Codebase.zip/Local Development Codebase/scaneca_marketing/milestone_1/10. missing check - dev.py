# For Development and Verification Purposes Only

import json

def is_empty_or_missing(value):
    return value is None or value == "" or (isinstance(value, list) and len(value) == 0)

def parse_json_file(input_file, output_file):
    with open(input_file, 'r') as f:
        data = json.load(f)
    
    missing_summary = {}
    
    for index, item in enumerate(data, start=1):
        missing_fields = []
        
        if is_empty_or_missing(item.get('address')):
            missing_fields.append('address')
        
        if is_empty_or_missing(item.get('postcode')):
            missing_fields.append('postcode')
        
        if is_empty_or_missing(item.get('email_ids')):
            missing_fields.append('email_ids')
        
        if missing_fields:
            missing_summary[str(index)] = missing_fields
    
    with open(output_file, 'w') as f:
        json.dump(missing_summary, f, indent=2)
    
    return missing_summary

if __name__ == "__main__":
    input_file = 'data/result.json'
    output_file = 'missing_fields_summary.json'
    
    summary = parse_json_file(input_file, output_file)
    
    print("Summary of missing fields:")
    for index, fields in summary.items():
        print(f"{index}: {fields}")
    
    print(f"\nDetailed summary has been saved to {output_file}")
