import os
import json
import time
from langchain.output_parsers import PydanticOutputParser
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate
from langchain_community.chat_models import ChatOpenAI 
from pydantic import BaseModel, Field
from typing import Optional



# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = ""

# This script analyzes text scraped from a base page using AI
# It extracts and processes information about specialists, including:
# - Title
# - First name
# - Last name
# - Gender (derived from the first name)
# - Country
# - City
# The extracted information is then combined with the original scraped data

class SpecialistInfo(BaseModel):
    title: Optional[str] = Field(description="The professional title (e.g., Dr., Prof.)")
    first_name: Optional[str] = Field(description="The first name of the specialist")
    last_name: Optional[str] = Field(description="The last name of the specialist")
    gender: Optional[str] = Field(description="The derived gender based on the first name")
    country: Optional[str] = Field(description="The country where the specialist is located")
    city: Optional[str] = Field(description="The city where the specialist practices")

class SpecialistInfoExtractor:
    def __init__(self):
        self.output_parser = PydanticOutputParser(pydantic_object=SpecialistInfo)
        self.llm = ChatOpenAI(model_name="gpt-4")

    def extract_info(self, input_text):
        prompt_template = """
        Given the following input, extract the requested information about the specialist:

        Input: {input_text}

        Please provide the following information:
        1. Title – The professional title (e.g., Dr., Prof.)
        2. First Name – The first name of the specialist
        3. Last Name – The last name of the specialist
        4. Gender – Derive this based on the first name
        5. Country – The country where the specialist is located
        6. City – The city where the specialist practices

        If any field is not present in the input, output null or an empty string. Do not make up any information.

        {format_instructions}
        """

        format_instructions = self.output_parser.get_format_instructions()
        prompt = ChatPromptTemplate(
            messages=[HumanMessagePromptTemplate.from_template(prompt_template)],
            input_variables=["input_text"],
            partial_variables={"format_instructions": format_instructions}
        )

        messages = prompt.format_messages(input_text=input_text)
        output = self.llm(messages)
        
        try:
            specialist_info = self.output_parser.parse(output.content)
            return (
                specialist_info.title or "",
                specialist_info.first_name or "",
                specialist_info.last_name or "",
                specialist_info.gender or "",
                specialist_info.country or "",
                specialist_info.city or ""
            )
        except Exception as e:
            print(f"Error parsing output: {e}")
            return "", "", "", "", "", ""
    
    def process_json_file(self, input_file, output_file):
        with open(input_file, 'r') as f:
            data = json.load(f)
        
        processed_data = []
        total_items = len(data)
        
        for index, item in enumerate(data, 1):
            
            time.sleep(2)
            
            full_text = item.get('full_text', '')
            url = item.get('url', '')
            domain = item.get('domain', '')

            print(f"\nFull Text: {full_text}\nURL: {url}\nDomain: {domain}\n") 
            
            title, first_name, last_name, gender, country, city = self.extract_info(full_text)
            
            print(f"\nTitle: {title}\nFirst Name: {first_name}\nLast Name: {last_name}\nGender: {gender}\nCountry: {country}\nCity: {city}\n")
            
            # Combine all extracted information into a single dictionary
            combined_info = {
                'full_text': full_text,
                'url': url,
                'domain': domain,
                'title': title,
                'first_name': first_name,
                'last_name': last_name,
                'gender': gender,
                'country': country,
                'city': city
            }
            
            processed_data.append(combined_info)
            
            # Print progress
            print(f"Processed item {index} of {total_items}")
        
        with open(output_file, 'w') as f:
            json.dump(processed_data, f, indent=2)

if __name__ == "__main__":
    input_file = 'data.json'
    output_file = 'data/2. data.json'
    extractor = SpecialistInfoExtractor()
    extractor.process_json_file(input_file, output_file)
    print(f"Processed data has been saved to {output_file}")
