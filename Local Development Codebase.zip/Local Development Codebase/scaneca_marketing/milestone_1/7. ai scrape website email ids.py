import json
import requests
from urllib.parse import quote

class EmailUpdater:
    def __init__(self):
        self.api_url = "https://ws-ai.app.n8n.cloud/webhook/emai_id"

    def get_email_id(self, url):
        encoded_url = quote(url)
        email_id_url = f"{self.api_url}?Website={encoded_url}"
        try:
            response = requests.get(email_id_url)
            response.raise_for_status()
            return response.text.strip()
        except requests.RequestException as e:
            print(f"Error fetching email ID for {url}: {e}")
            return None

    def process_json_file(self, input_file, output_file):
        with open(input_file, 'r') as f:
            data = json.load(f)
        
        total_items = len(data)
        updated_count = 0
        
        for index, item in enumerate(data, start=1):
            print(f"\nProcessing {index}/{total_items}")
            
            if not item.get('email_ids'):
                url = item.get('url')
                if url:
                    email_id = self.get_email_id(url)
                    if email_id:
                        item['email_ids'] = [email_id]
                        updated_count += 1
                        print(f"Updated email ID for {url}: {email_id}")
                    else:
                        print(f"Couldn't retrieve email ID for {url}")
                else:
                    print("No URL available")
            else:
                print("Email IDs already present")
        
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"\nUpdated {updated_count} out of {total_items} items")

if __name__ == "__main__":
    input_file = 'data/6. data.json'
    output_file = 'data/7. data.json'
    updater = EmailUpdater()
    updater.process_json_file(input_file, output_file)
    print(f"Processed data has been saved to {output_file}")
