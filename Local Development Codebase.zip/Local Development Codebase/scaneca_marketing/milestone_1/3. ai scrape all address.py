import json
import requests
import time

# This script processes entries from a JSON file, extracting contact information:

# - It takes the domain and webpage_url for each entry
# - Fetches contact information from the main webpage
# - Attempts to find a contact page URL
# - If a contact page is found, it fetches address information from there as well
# - Both sets of contact information (from main page and contact page) are saved

# The script processes entries one by one, with a delay between each to avoid overloading the server

def fetch_address(url):
    address_api_url = f"https://ws-ai.app.n8n.cloud/webhook/get_address?webpage_url={url}"
    response = requests.get(address_api_url)
    response.raise_for_status()
    return response.text.strip()

def fetch_contact_url(url, domain):
    kontakt_api_url = f"https://ws-ai.app.n8n.cloud/webhook/get_kontakt_page?webpage_url={url}&domain={domain}"
    response = requests.get(kontakt_api_url)
    response.raise_for_status()
    return response.text.strip()

def process_entry(entry):
    url = entry['url']
    domain = entry['domain']

    print(f"\nurl : {url}\ndomain : {domain}\n")

    # Fetch address from main URL
    address1 = fetch_address(url)
    print(f"Address from main URL: {address1}")

    # Fetch contact page URL
    contact_url = fetch_contact_url(url, domain)
    print(f"Contact page URL: {contact_url}")

    # Fetch address from contact page URL
    address2 = fetch_address(contact_url)
    print(f"Address from contact page: {address2}")

    # Combine results
    contact_information = {
        "contact_information_1": address1,
        "contact_information_2": address2
    }

    # Add contact_information to the entry without modifying other fields
    entry['contact_information'] = contact_information

    return entry

def main():
    # Read JSON file
    with open('data/2. data.json', 'r') as f:
        data = json.load(f)

    total_entries = len(data)
    processed_data = []

    print(f"Total entries to process: {total_entries}")

    for index, entry in enumerate(data, start=1):
        print(f"\nProcessing {index}/{total_entries}")
        processed_entry = process_entry(entry)
        print(f"Processed entry: {processed_entry}")
        processed_data.append(processed_entry)
        time.sleep(2)  # Add a 2-second delay between processing each entry

    print("\nAll entries processed.")

    # Write updated data to a new JSON file
    with open('data/3. data.json', 'w') as f:
        json.dump(processed_data, f, indent=2)

    print("Updated data has been written to 'data/updated_data.json'")

if __name__ == "__main__":
    main()
