import os
import json
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate
from langchain_community.chat_models import ChatOpenAI

# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = ""

# This script updates missing country information in a dataset:

# - It processes a JSON file containing location data
# - For entries where the country field is empty, it uses AI to determine the country based on the city
# - The AI model (GPT-4) is prompted to provide the country name for a given city
# - If the AI can't determine the country with confidence, it leaves the field as is
# - The script updates the JSON file with the newly determined country information
# - It keeps track of how many entries were updated and provides a summary at the end

class CountryUpdater:
    def __init__(self):
        self.llm = ChatOpenAI(model_name="gpt-4")

    def get_country(self, city):
        prompt_template = """
        Based on the following city name, provide the name of the country it is located in. 
        If you're not certain, respond with "Unknown". Do not make up any information.

        City: {city}

        Country:
        """

        prompt = ChatPromptTemplate(
            messages=[HumanMessagePromptTemplate.from_template(prompt_template)],
            input_variables=["city"]
        )

        messages = prompt.format_messages(city=city)
        output = self.llm(messages)

        return output.content.strip()

    def process_json_file(self, input_file, output_file):
        with open(input_file, 'r') as f:
            data = json.load(f)
        
        total_items = len(data)
        updated_count = 0
        
        for index, item in enumerate(data, start=1):
            print(f"\nProcessing {index}/{total_items}")
            
            if item.get('country', '') == '':
                city = item.get('city', '')
                if city:
                    country = self.get_country(city)
                    if country.lower() != 'unknown':
                        item['country'] = country
                        updated_count += 1
                        print(f"Updated country for {city}: {country}")
                    else:
                        print(f"Couldn't determine country for {city}")
                else:
                    print("No city information available")
            else:
                print("Country already present")
        
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"\nUpdated {updated_count} out of {total_items} items")

if __name__ == "__main__":
    input_file = 'data/5. data.json'
    output_file = 'data/6. data.json'
    updater = CountryUpdater()
    updater.process_json_file(input_file, output_file)
    print(f"Processed data has been saved to {output_file}")
