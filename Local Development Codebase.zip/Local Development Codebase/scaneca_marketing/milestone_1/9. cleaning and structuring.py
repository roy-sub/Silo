import json
import csv
import codecs

# Read the input JSON file
with open('data/8. data.json', 'r', encoding='utf-8') as file:
    data = json.load(file)

# Process the data
result = []
for item in data:
    processed_item = {
        "full_text": item.get("full_text", ""),
        "url": item.get("url", ""),
        "domain": item.get("domain", ""),
        "title": item.get("title", ""),
        "first_name": item.get("first_name", ""),
        "last_name": item.get("last_name", ""),
        "gender": item.get("gender", ""),
        "country": item.get("country", ""),
        "city": item.get("city", ""),
        "Address": item.get("Address", ""),
        "postcode": item.get("postcode", ""),
        "email_ids": item.get("email_ids", []),
        "phone_numbers": item.get("phone_numbers", [])
    }
    
    # Convert Unicode escape sequences
    for key, value in processed_item.items():
        if isinstance(value, str):
            processed_item[key] = codecs.decode(value, 'unicode_escape')
        elif isinstance(value, list):
            processed_item[key] = [codecs.decode(v, 'unicode_escape') if isinstance(v, str) else v for v in value]
    
    result.append(processed_item)

# Save as JSON
with open('data/result.json', 'w', encoding='utf-8') as file:
    json.dump(result, file, ensure_ascii=False, indent=2)

# Save as CSV
with open('data/result.csv', 'w', newline='', encoding='utf-8') as file:
    writer = csv.DictWriter(file, fieldnames=result[0].keys())
    writer.writeheader()
    for row in result:
        # Convert lists to strings for CSV
        row_copy = row.copy()
        for key, value in row_copy.items():
            if isinstance(value, list):
                row_copy[key] = ', '.join(map(str, value))
        writer.writerow(row_copy)

print("Processing complete. Files saved as 'data/result.json' and 'data/result.csv'.")
