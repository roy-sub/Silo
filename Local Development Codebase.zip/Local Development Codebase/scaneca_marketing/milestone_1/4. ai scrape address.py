import os
import json
import time
from langchain.output_parsers import PydanticOutputParser
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate
from langchain_community.chat_models import ChatOpenAI 
from pydantic import BaseModel, Field
from typing import List, Optional

# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = ""

# This script processes contact information for decision makers:

# - It takes two sets of contact information previously scraped from webpages
# - Using AI, it analyzes and combines these into a single, accurate set of contact details
# - The script formulates a single mailing address for the decision maker
# - It also extracts and consolidates phone numbers and email addresses
# - The processed information is then saved to a new JSON file, combining it with other existing data

class ContactInfo(BaseModel):
    Address: str = Field(description="The full address of the specialist")
    Postcode: str = Field(description="The postcode of the address")
    Phone_Numbers: List[str] = Field(description="List of phone numbers")
    Email_IDs: List[str] = Field(description="List of email addresses")

class ContactInfoProcessor:
    def __init__(self):
        self.llm = ChatOpenAI(model_name="gpt-4")
        self.output_parser = PydanticOutputParser(pydantic_object=ContactInfo)

    def process_contact_info(self, contact_info1, contact_info2):
        prompt_template = """
        Based on the following two pieces of contact information, provide a single, accurate set of contact details. Do not combine addresses if they are different, and do not make up any information. If there are conflicts, choose the most complete and accurate information.

        Contact Information 1:
        {contact_info1}

        Contact Information 2:
        {contact_info2}

        If any field is not present in the input, output an empty string or an empty list as appropriate. Do not make up any information.

        {format_instructions}
        """

        format_instructions = self.output_parser.get_format_instructions()
        prompt = ChatPromptTemplate(
            messages=[HumanMessagePromptTemplate.from_template(prompt_template)],
            input_variables=["contact_info1", "contact_info2"],
            partial_variables={"format_instructions": format_instructions}
        )

        messages = prompt.format_messages(contact_info1=contact_info1, contact_info2=contact_info2)
        output = self.llm(messages)

        try:
            processed_info = self.output_parser.parse(output.content)
            return processed_info.dict()
        except Exception as e:
            print(f"Error parsing output: {e}")
            return {
                "Address": "",
                "Postcode": "",
                "Phone_Numbers": [],
                "Email_IDs": []
            }

    def process_json_file(self, input_file, output_file):
        with open(input_file, 'r') as f:
            data = json.load(f)
        
        processed_data = []
        
        for index, item in enumerate(data, start=1):
            print(f"\nProcessing item {index}/{len(data)}\n")
            try:
                contact_info1 = json.loads(item['contact_information']['contact_information_1'])
                contact_info2 = json.loads(item['contact_information']['contact_information_2'])
                
                processed_contact_info = self.process_contact_info(contact_info1, contact_info2)
                print(f"processed_contact_info:{processed_contact_info}\n")
                
                processed_item = {
                    "full_text": item.get('full_text', ''),
                    "url": item.get('url', ''),
                    "domain": item.get('domain', ''),
                    "title": item.get('title', ''),
                    "first_name": item.get('first_name', ''),
                    "last_name": item.get('last_name', ''),
                    "gender": item.get('gender', ''),
                    "country": item.get('country', ''),
                    "city": item.get('city', ''),
                    "address": processed_contact_info.get('Address', ''),
                    "postcode": processed_contact_info.get('Postcode', ''),
                    "phone_numbers": processed_contact_info.get('Phone_Numbers', []),
                    "email_ids": processed_contact_info.get('Email_IDs', [])
                }
                
                processed_data.append(processed_item)
            except Exception as e:
                print(f"Error processing item: {e}")
                continue
        
        with open(output_file, 'w') as f:
            json.dump(processed_data, f, indent=2)

if __name__ == "__main__":
    input_file = 'data/3. data.json'
    output_file = 'data/4. data.json'
    processor = ContactInfoProcessor()
    processor.process_json_file(input_file, output_file)
    print(f"Processed data has been saved to {output_file}")
