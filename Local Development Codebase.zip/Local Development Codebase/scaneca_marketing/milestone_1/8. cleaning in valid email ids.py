import json
import re

class EmailCleaner:
    def __init__(self):
        # Regular expression for basic email validation
        self.email_regex = re.compile(r"[^@]+@[^@]+\.[^@]+")
        
        # List of invalid top-level domains (TLDs) for email addresses
        self.invalid_tlds = ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff', '.webp']

    def is_valid_email(self, email):
        # Check if the email matches the basic pattern
        if not self.email_regex.match(email):
            return False
        
        # Check if the email ends with any of the invalid TLDs
        return not any(email.lower().endswith(tld) for tld in self.invalid_tlds)

    def process_json_file(self, input_file, output_file):
        with open(input_file, 'r') as f:
            data = json.load(f)
        
        total_items = len(data)
        total_removed = 0
        
        for index, item in enumerate(data, start=1):
            print(f"\nProcessing item {index}/{total_items}")
            
            if 'email_ids' in item:
                original_emails = item['email_ids']
                valid_emails = [email for email in original_emails if self.is_valid_email(email)]
                removed_emails = set(original_emails) - set(valid_emails)
                
                if removed_emails:
                    print(f"Removed {len(removed_emails)} invalid email(s) for item {index}")
                    print("Removed emails:")
                    for email in removed_emails:
                        print(f"  - {email}")
                    print(f"Original email count: {len(original_emails)}")
                    print(f"Remaining valid email count: {len(valid_emails)}")
                    total_removed += len(removed_emails)
                else:
                    print(f"No invalid emails found for item {index}")
                
                item['email_ids'] = valid_emails
            else:
                print(f"No email_ids field found for item {index}")
        
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"\nProcessed {total_items} items")
        print(f"Total invalid emails removed: {total_removed}")
        print(f"Cleaned data has been saved to {output_file}")

if __name__ == "__main__":
    input_file = 'data/7. data.json'
    output_file = 'data/8. data.json'
    cleaner = EmailCleaner()
    cleaner.process_json_file(input_file, output_file)