import traceback
import unicodedata
from constants import *
from ai_search import GoogleMapSearch
from scraper import GoogleMapsScraper
from data_post_processing import DataPostProcessing

class Generator:

  def __init__(self):
    pass

  def generate_files(self, search_term, search_location, search_radius, user_emailID,
                     user_name=""):
    try:
      # Get AI Searches

      print(f"\nStarting AI Automation\n")
    
      related_terms = GoogleMapSearch().get_related_search_terms(search_term)
      print(f"\nAI Generated Search Terms: {related_terms}\n")

      nearby_locations = GoogleMapSearch().get_nearby_locations(
          search_location, search_radius)
      print(f"\nNearby Locations with {search_radius}km: {nearby_locations}\n")

      gm_search_dict = GoogleMapSearch().get_google_map_searches(
          related_terms, nearby_locations)
      
      # gm_search_dict = {k: v for k, v in gm_search_dict.items() if k <= 5} # Not for the production Environment

      print(f"\nAI Generated Searches: {gm_search_dict}\n")

      # Scrape Google Maps

      print(f"\nStarting Google Map scraping\n")

      data = []

      for _, value in gm_search_dict.items():

        query = f"{value[0]} in {value[1]}"
        query = ''.join(c for c in unicodedata.normalize('NFD', query) if unicodedata.category(c) != 'Mn') 

        place = query.replace(' ', '+')
        url = f"https://www.google.com/maps/search/{place}"

        print(f"\nquery: {query}")
        print(f"url: {url}\n")

        try:
          scraper = GoogleMapsScraper()
          result = scraper.scrape_google_maps_titles_and_href(url, query)
          data.extend(result)

        except Exception as e:
          print(f"Error occurred: {e}. Skipping this query.")
          continue

      # Filter the Data
        
      filtered_data = {d['title']: d for d in data}
      filtered_list = list(filtered_data.values())

      # filtered_list = filtered_list[:150] # Not for the production Environment

      print(f"\nNumber of Entries to be Scraped: {len(filtered_list) }")
      print(f"Entries: {filtered_list}\n")

      final_result = []

      for poi in filtered_list:

        title = poi['title']
        url = poi['href']

        print(f"\ntitle: {title}\n url: {url}\n")

        try:
          scraper = GoogleMapsScraper()
          result = scraper.scrape_poi(title, url)
          final_result.append(result)

        except Exception as e:
          print(f"Error occurred: {e}. Skipping this query.")
          continue

      print(f"\nResult Before Data Cleaning: {final_result}\n")
      
      # Data Post Processing
      dataPostProcessing = DataPostProcessing()
      saved_excel_path = dataPostProcessing.raw_data_to_excel(final_result)

      return f"Procees Successfull - Final Result is Saved here : {saved_excel_path}"

    except Exception as e:

      print(f"Error occurred: {e}")

      traceback.print_exc()

      return "Process Failed"
