import pandas as pd
from datetime import datetime
import os

class DataPostProcessing:
    def __init__(self, output_dir='scraped_data'):
        self.output_dir = output_dir

    def raw_data_to_excel(self, raw_data):
        # Convert the list of dictionaries to a pandas DataFrame
        df = pd.DataFrame(raw_data)

        # Reorder columns to have 'title' as the first column
        columns = ['title'] + [col for col in df.columns if col != 'title']
        df = df[columns]

        # Convert the 'reviews' column to a string representation
        df['reviews'] = df['reviews'].apply(lambda x: '\n'.join(x) if isinstance(x, list) else x)

        # Create output directory if it doesn't exist
        os.makedirs(self.output_dir, exist_ok=True)

        # Generate a unique filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = os.path.join(self.output_dir, f"dentist_data_{timestamp}.xlsx")

        # Write the DataFrame to an Excel file
        df.to_excel(output_file, index=False, engine='openpyxl')
        print(f"Excel file '{output_file}' has been created and saved successfully.")

        return output_file