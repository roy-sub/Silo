import os
from langchain.output_parsers import CommaSeparatedListOutputParser
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate
from constants import SEARCH_TERM_TEMPLATE_STRING, SEARCH_LOCATION_TEMPLATE_STRING, SEARCH_RADIUS, AI_SEARCH_LIMIT
from geo_location import LocationValidator
from langchain_community.chat_models import ChatOpenAI 

os.environ[
    "OPENAI_API_KEY"] = "sk-proj-Mb9r0t6o4khkKAvMsLVFT3BlbkFJ4y58l1ljLofqgEu9AXKG"

class GoogleMapSearch:

  def __init__(self):
    self.output_parser = CommaSeparatedListOutputParser()
    self.llm = ChatOpenAI(temperature=0.0)  # model_name="text-davinci-003"

  def get_related_search_terms(self, search_term):
    format_instructions = self.output_parser.get_format_instructions()
    search_term_prompt = ChatPromptTemplate(messages=[
        HumanMessagePromptTemplate.from_template(SEARCH_TERM_TEMPLATE_STRING)
    ],
                                            input_variables=["industry_name"],
                                            partial_variables={
                                                "format_instructions":
                                                format_instructions
                                            })
    search_term_messages_for_list_prompt = search_term_prompt.format_messages(
        industry_name=search_term, format_instructions=format_instructions)
    search_term_output = self.llm(search_term_messages_for_list_prompt)
    related_terms = self.output_parser.parse(search_term_output.content)
    related_terms = related_terms[:AI_SEARCH_LIMIT]
    related_terms.append(search_term)
    return related_terms

  def get_nearby_locations(self, search_location, search_radius):
    format_instructions = self.output_parser.get_format_instructions()
    search_location_prompt = ChatPromptTemplate(
        messages=[
            HumanMessagePromptTemplate.from_template(
                SEARCH_LOCATION_TEMPLATE_STRING)
        ],
        input_variables=["location_name"],
        partial_variables={"format_instructions": format_instructions})
    search_location_messages_for_list_prompt = search_location_prompt.format_messages(
        location_name=search_location, format_instructions=format_instructions)
    search_location_output = self.llm(search_location_messages_for_list_prompt)
    nearby_locations = self.output_parser.parse(search_location_output.content)
    nearby_locations = LocationValidator().validate_locations(
        nearby_locations, search_location, search_radius)
    nearby_locations.append(search_location)
    return nearby_locations 

  def get_google_map_searches(self, related_terms, nearby_locations):
    gm_search_dict = {}
    for i in range(len(related_terms)):
      for j in range(len(nearby_locations)):
        loc = nearby_locations[j].capitalize()
        lat, lon = LocationValidator().get_latitude_longitude(loc)
        if lat is not None and lon is not None:
          gm_search_dict[len(gm_search_dict) + 1] = [
              related_terms[i].capitalize(), nearby_locations[j].capitalize(),
              f"@{lat},{lon},9z"
          ]
    return gm_search_dict


if __name__ == "__main__":
  google_map_search = GoogleMapSearch()
  search_term = "Coffee Shops"
  search_location = "New York"
  related_terms = google_map_search.get_related_search_terms(search_term)
  nearby_locations = google_map_search.get_nearby_locations(search_location)
  gm_search_dict = google_map_search.get_google_map_searches(
      related_terms, nearby_locations)
  print(gm_search_dict)
  print(len(gm_search_dict))
