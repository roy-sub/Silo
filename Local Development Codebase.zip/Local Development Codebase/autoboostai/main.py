import re
import os
import time
import json
import csv
from selenium import webdriver
from constants import CHROME_DRIVER_PATH
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException

# Stage 1: Dynamic Data Loading and URL Extraction
# This stage involves simulating user scrolling on Google Maps to trigger dynamic content loading.
# It ensures comprehensive data collection by continuously scrolling until all available business
# listings are loaded. Once loaded, it extracts individual URLs for each business, preparing
# for detailed scraping in the next stage.

class GoogleMapsScraper:
  def __init__(self):
    os.chmod(CHROME_DRIVER_PATH,0o755) 
    chrome_options = webdriver.ChromeOptions()
    
    # Add these options for headless mode
    chrome_options.add_argument('--headless')  # Run in headless mode
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    # Optional but recommended options
    chrome_options.add_argument('--disable-gpu')  # Disable GPU hardware acceleration
    chrome_options.add_argument('--window-size=1920,1080')  # Set window size
        
    self.driver = webdriver.Chrome(options=chrome_options) 

  def scrape_google_maps_titles_and_href(self, url, query):
    self.driver.get(url)

    divSideBar = self.driver.find_elements(By.CSS_SELECTOR, f'div[aria-label*="Results for {query}"]')
    divSideBar = divSideBar[0]

    keepScrolling=True
    start_time = time.time()

    while(keepScrolling):
        divSideBar.send_keys(Keys.PAGE_DOWN)
        time.sleep(0.5)
        divSideBar.send_keys(Keys.PAGE_DOWN)
        time.sleep(0.5)
        html =self.driver.find_element(By.TAG_NAME, "html").get_attribute('outerHTML')
        if(html.find("You've reached the end of the list.")!=-1 or time.time() - start_time > 60):
            keepScrolling=False

    elements = self.driver.find_elements(By.CLASS_NAME, "hfpxzc")

    data = []

    for element in elements:
      aria_label = element.get_attribute("aria-label")
      if aria_label:
          entry = {
              "title": aria_label,
              "href": element.get_attribute("href")
          }
          data.append(entry)

    return data

if __name__ == "__main__":
    scraper_processor = GoogleMapsScraper()
    
    query = "Dentists in Zurich" # Input
    url = f"https://www.google.com/maps/search/{'+'.join(query.split())}"
    all_profiles = scraper_processor.scrape_google_maps_titles_and_href(url, query)
    print(f"Total number of profiles: {len(all_profiles)}\n\n{all_profiles}")
