import re
import os
import time
import json
import csv
from selenium import webdriver
from constants import CHROME_DRIVER_PATH
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException

# Stage 1: Dynamic Data Loading and URL Extraction
# This stage involves simulating user scrolling on Google Maps to trigger dynamic content loading.
# It ensures comprehensive data collection by continuously scrolling until all available business
# listings are loaded. Once loaded, it extracts individual URLs for each business, preparing
# for detailed scraping in the next stage.

class GoogleMapsScraper:
  def __init__(self):
    os.chmod(CHROME_DRIVER_PATH,0o755) 
    chrome_options = webdriver.ChromeOptions()
    
    # Add these options for headless mode
    chrome_options.add_argument('--headless')  # Run in headless mode
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    # Optional but recommended options
    chrome_options.add_argument('--disable-gpu')  # Disable GPU hardware acceleration
    chrome_options.add_argument('--window-size=1920,1080')  # Set window size
        
    self.driver = webdriver.Chrome(options=chrome_options) 

  def scrape_google_maps_titles_and_href(self, url, query):
    self.driver.get(url)

    divSideBar = self.driver.find_elements(By.CSS_SELECTOR, f'div[aria-label*="Results for {query}"]')
    divSideBar = divSideBar[0]

    keepScrolling=True
    start_time = time.time()

    while(keepScrolling):
        divSideBar.send_keys(Keys.PAGE_DOWN)
        time.sleep(0.5)
        divSideBar.send_keys(Keys.PAGE_DOWN)
        time.sleep(0.5)
        html =self.driver.find_element(By.TAG_NAME, "html").get_attribute('outerHTML')
        if(html.find("You've reached the end of the list.")!=-1 or time.time() - start_time > 60):
            keepScrolling=False

    elements = self.driver.find_elements(By.CLASS_NAME, "hfpxzc")

    data = []

    for element in elements:
      aria_label = element.get_attribute("aria-label")
      if aria_label:
          entry = {
              "title": aria_label,
              "href": element.get_attribute("href")
          }
          data.append(entry)

    return data

# Stage 2: Detailed Business Information Extraction
# In this stage, the scraper navigates to each individual business URL collected in Stage 1.
# It then extracts comprehensive information about each business, including but not limited to
# name, address, contact details, operating hours, customer reviews, and ratings. This granular
# data collection provides a rich dataset for analysis.
  
  def scrape_poi(self, url):
    
    print(f"\n\nurl: {url}\n\n")
    
    self.driver.get(url)

    # 1. Scrape Title
    try:
        title_name = self.driver.find_element(By.CSS_SELECTOR, "h1.DUwDvf").text.strip()
    except NoSuchElementException:
        title_name = ""
    
    print(f"\ntitle_name: {title_name}\n")
    
    # 2. Scrape Average Rating

    try:
      avg_rating_element = self.driver.find_element(by=By.XPATH, value="//div[contains(@class, 'F7nice')]//span[contains(@aria-hidden, 'true')]")
      avg_rating = avg_rating_element.text
    except NoSuchElementException:
      avg_rating = ""
    
    # 3. Scrape Total Number of ratings
    
    try:
      total_reviews_element = self.driver.find_element(by=By.XPATH, value="//div[contains(@class, 'F7nice')]//span[contains(@aria-label, 'reviews')]")
      total_number_of_reviews = total_reviews_element.text
      total_number_of_reviews = total_number_of_reviews.replace('(', '').replace(')', '') 
    except NoSuchElementException:
      total_number_of_reviews = ""
    
    # 4. Scrape Description
    
    try:
      description = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "h2.bwoZTb.fontBodyMedium span"))).text.strip()
    except (TimeoutException, NoSuchElementException):
      description = ""
    
    # 5. Scrape Service Category
    
    try:
        category = self.driver.find_element(By.CSS_SELECTOR, "button.DkEaL").text.strip()
    except NoSuchElementException:
        category = ""
    
    # 6. Scrape Address
    
    try:
      address_button = self.driver.find_element(By.CSS_SELECTOR, 'button[aria-label^="Address"]')
      address = address_button.get_attribute('aria-label').split(': ')[1]
    except NoSuchElementException:
      address = ""
    
    # 7. Scrape Open Hours
    try:
      open_hours = self.driver.find_element(By.CSS_SELECTOR, '.t39EBf.GUrTXd').get_attribute('aria-label')
    except NoSuchElementException:
      open_hours = ""
    
    # 8. Scrape Website Link
    try:
      website = self.driver.find_element(By.CSS_SELECTOR, 'a[aria-label^="Website"]')
      website_link = website.get_attribute('href')
    except NoSuchElementException:
      website_link = ""
    
    # 9. Scrape Phone Number
    
    try:
      phone_button = self.driver.find_element(By.CSS_SELECTOR, 'button[aria-label^="Phone"]')
      phone_button_text = phone_button.text
      phone_number = phone_button_text.split('\n')[-1]
    except NoSuchElementException:
      phone_number = ""
    
    # 10. Scrape Reviews
    
    reviews = []
    
    try:
      review_elements = self.driver.find_elements(By.CSS_SELECTOR, '.DUGVrf [jslog*="track:click"]')
      review_texts = [element.get_attribute('aria-label') for element in review_elements]
    
      for review_text in review_texts:
          review_text = re.search('"([^"]*)"', review_text).group(1)
          reviews.append(review_text)
    
    except NoSuchElementException:
      pass
    
    try:
      review_elements = self.driver.find_elements(By.CSS_SELECTOR, '.wiI7pd')
      review_texts = [element.text for element in review_elements]
    
      for review_text in review_texts:
          reviews.append(review_text)
    
    except NoSuchElementException:
      pass
    
    # 11. Profile Photo
    
    try:
      # Find the button containing the profile picture
      profile_picture_button = self.driver.find_element(By.CSS_SELECTOR, 'button.aoRNLd[aria-label^="Photo of"]')
      
      # Find the img element within the button
      img_element = profile_picture_button.find_element(By.TAG_NAME, 'img')
      
      # Get the src attribute of the img element
      profile_picture_url = img_element.get_attribute('src')

    except NoSuchElementException:
      profile_picture_url = ""
    
    # 12. Scrape About Tab : Presence of any unique selling points + Additional business categories
    
    about = {}
    
    try:
      # Wait for the About tab to be clickable and then click it
      about_tab = WebDriverWait(self.driver, 10).until(
          EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[aria-label^="About"][role="tab"]'))
      )
      about_tab.click()
      
      # Wait for the About section to load
      WebDriverWait(self.driver, 10).until(
          EC.presence_of_element_located((By.CSS_SELECTOR, 'div[aria-label^="About"]'))
      )
      
      # Find the main about section
      about_section = self.driver.find_element(By.CSS_SELECTOR, 'div[aria-label^="About"]')
      
      # Find all subsections (e.g., Accessibility, Amenities, etc.)
      subsections = about_section.find_elements(By.CSS_SELECTOR, 'div.iP2t7d.fontBodyMedium')
      
      for subsection in subsections:
        # Get the subsection title
        title = subsection.find_element(By.CSS_SELECTOR, 'h2.iL3Qke.fontTitleSmall').text
        
        # Find all items in the subsection
        items = subsection.find_elements(By.CSS_SELECTOR, 'li.hpLkke span')
        
        # Extract the text from each item
        item_texts = [item.text for item in items]
        
        # Add the subsection and its items to the about dictionary
        about[title] = item_texts
  
    except (NoSuchElementException, TimeoutException):
      pass
    
    print(f"\n re checking title_name: {title_name}\n")

    result = {
        "url": url,
        "title": title_name,
        "avg_rating": avg_rating,
        "total_number_of_reviews": total_number_of_reviews,
        "description": description,
        "category": category,
        "address": address,
        "open_hours": open_hours,
        "website": website_link,
        "phone_number": phone_number,
        "reviews": reviews,
        "profile_picture_url": profile_picture_url,
        "about": about
    }

    return result

# Stage 3: Process Integration and Workflow Automation
# This final stage focuses on combining and streamlining the previous three stages into a
# cohesive, automated workflow. It encapsulates the entire process from initial data loading
# to final output generation in a single, efficient operation. This integration ensures smooth
# data flow between stages, minimizes manual intervention, and provides a unified interface
# for executing the entire scraping and processing pipeline. The result is a more robust,
# maintainable, and user-friendly system that can handle the end-to-end process of data
# collection, processing, and output generation.

class Generator:
    def __init__(self, output_dir='scraped_data'):
        self.scraper = GoogleMapsScraper()
        self.output_dir = output_dir
    
    def save_as_json(self, data):
        if not data:
          print("No data to save.")
          return

        os.makedirs(self.output_dir, exist_ok=True)
        output_file = os.path.join(self.output_dir, 'scraped_data.json')

        with open(output_file, 'w', encoding='utf-8') as jsonfile:
          json.dump(data, jsonfile, ensure_ascii=False, indent=4)

        print(f"Data saved to {output_file}")
    
    def save_as_csv(self, data):
        if not data:
            print("No data to save.")
            return

        os.makedirs(self.output_dir, exist_ok=True)
        output_file = os.path.join(self.output_dir, 'scraped_data.csv')

        # Get all unique keys from all dictionaries in the data
        fieldnames = set()
        for item in data:
            fieldnames.update(item.keys())

        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in data:
                writer.writerow(row)

        print(f"Data saved to {output_file}")

    def scrape(self, query, url):
        data = []
        result = self.scraper.scrape_google_maps_titles_and_href(url, query)
        data.extend(result)

        filtered_data = {d['title']: d for d in data}
        filtered_list = list(filtered_data.values())
        print(f"Number of Accounts that can be scraped: {len(filtered_list)}\n")
        
        # Preproduction Step
        filtered_list = filtered_list[:25]
        print(f"Number of Accounts to be scraped: {len(filtered_list)}\n")
        ##

        final_result = []

        for poi in filtered_list:
            title = poi['title']
            url = poi['href']
            result = self.scraper.scrape_poi(url)
            print(f"result: {result}\n\n")
            final_result.append(result)
        
        print(f"\n\nFinal Result: \n\n{final_result}\n\n")
        
        print("\nEntering Data Post Processing\n")
        
        self.save_as_json(final_result)
        self.save_as_csv(final_result)
        
        return True

# Example usage ( Unit Testing )

if __name__ == "__main__":
    scraper_processor = Generator()
    
    query = "Dentists in Zurich" # Input
    
    url = f"https://www.google.com/maps/search/{'+'.join(query.split())}"
    saved_excel_path = scraper_processor.scrape(query, url)
    print(f"The Excel file has been saved as: {saved_excel_path}")
 