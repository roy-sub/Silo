import os
import time
import json
from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait

# Change the permissions of the chromedriver which allows the owner to execute the file and allows 
# others to read and execute it.

os.chmod('/home/subhrastien/Development/scraper_dev/chromedriver',0o755) 

class InstagramScraper:
    def __init__(self, username, password, target_username):
        self.username = username
        self.password = password
        self.target_username = target_username
        self.driver = self.setup_driver()

    # Set up WebDriver with proxy options
    
    def setup_driver(self):
        chrome_options = webdriver.ChromeOptions()
        
        # Important : Add Resedential Proxy
        # chrome_options.add_argument('proxy.soax.com'.format(PROXY))
        
        return webdriver.Chrome(options=chrome_options)

    # Log in to Instagram
    
    def login(self):
        self.driver.get("https://www.instagram.com/accounts/login/")
        
        username_input = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.NAME, "username")))
        password_input = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.NAME, "password")))
        login_button = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//div[text()='Log in']")))
        
        time.sleep(5)
        username_input.clear()
        username_input.send_keys(self.username)
        
        time.sleep(5)
        password_input.clear()
        password_input.send_keys(self.password)
        
        time.sleep(5)
        login_button.click()
        time.sleep(30)

    # Scraping the Required Data from Instagram
    
    def scrape_instagram(self):
        self.login()
        self.driver.get(f"https://www.instagram.com/{self.target_username}")
        
        # Scrape Account Info
                    
        time.sleep(15) 
        profile_pic_elements = self.driver.find_elements(By.CSS_SELECTOR, 'img.xpdipgo.x972fbf.xcfux6l.x1qhh985.xm0m39n.xk390pu.x5yr21d.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.xl1xv1r.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x11njtxf.xh8yej3')
        profile_pic_src = profile_pic_elements[1].get_attribute('src')
        
        time.sleep(5)
        elements = self.driver.find_elements(By.CSS_SELECTOR, '.xl565be.x1m39q7l.x1uw6ca5.x2pgyrj')
        
        try:
            number_of_post = elements[0].text
        except IndexError:
            number_of_post = ""

        try:
            number_of_followers = elements[1].text
        except IndexError:
            number_of_followers = ""

        try:
            number_of_followings = elements[2].text
        except IndexError:
            number_of_followings = ""
        
        print(f"{number_of_post} {number_of_followers} {number_of_followings}")
        
        time.sleep(5)
        full_name_element = self.driver.find_element(By.CSS_SELECTOR, 'span.x1lliihq.x1plvlek.xryxfnj.x1n2onr6.x193iq5w.xeuugli.x1fj9vlw.x13faqbe.x1vvkbs.x1s928wv.xhkezso.x1gmr53x.x1cpjm7i.x1fgarty.x1943h6x.x1i0vuye.xvs91rp.x1s688f.x5n08af.x10wh9bi.x1wdrske.x8viiok.x18hxmgj')
        full_name_text = full_name_element.text
        
        time.sleep(5)
        profession_element = self.driver.find_element(By.CLASS_NAME, '_ap3a._aaco._aacu._aacy._aad6._aade')
        profession_text = profession_element.text
        
        time.sleep(5)
        bio_element = self.driver.find_element(By.CLASS_NAME, '_ap3a._aaco._aacu._aacx._aad6._aade')
        bio_text = bio_element.get_attribute('innerHTML')
        
        time.sleep(5)
        external_link_element = self.driver.find_element(By.CLASS_NAME, '_ap3a._aaco._aacw._aacz._aada._aade')
        external_link_src = external_link_element.text
        
        plus_index = external_link_src.find('+')
        if plus_index != -1:
            external_link_src = external_link_src[:plus_index-1]
                        
        acc_info = {
            "profile_picture": profile_pic_src,
            "number_of_post": number_of_post,
            "number_of_followers": number_of_followers,
            "number_of_followings": number_of_followings,
            "full_name": full_name_text,
            "profession": profession_text, # category
            "bio": bio_text,
            "external_link": external_link_src
        }
        
        print(f"acc_info: {acc_info}") 

        # Pending - Save Account Info 
        
        # Scrape Image URL, Video / Reel Thumnail URL and their Corresponding Captions
        
        time.sleep(15)
        last_height = self.driver.execute_script("return document.body.scrollHeight") 
        
        posts = []

        # Scroll to load more images
        
        while True:
            
            time.sleep(5)
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            
            time.sleep(5)
            post_elements = self.driver.find_elements(By.CLASS_NAME, '_aagv')

            # Extract image source and caption
            
            for post_element in post_elements:
                img_element = post_element.find_element(By.TAG_NAME, 'img')
                
                caption = img_element.get_attribute('alt')
                image_link = img_element.get_attribute('src')
                
                post = [image_link, caption]
                posts.append(post) 
                
                #DEBUG
                print(f"post: {post}")
                print(f"posts: {posts}")

            time.sleep(5)
            new_height = self.driver.execute_script("return document.body.scrollHeight")

            if new_height == last_height:
                break

            last_height = new_height

        # Pending - Saving the Post Data
        print(f"posts: {posts}")
        
        time.sleep(30)
        self.driver.quit()
            
if __name__ == "__main__":
  
  username = "de.clairmont"
  password = "Ourdemocracy@99"
  target_username = "elenataber"
  
  scraper = InstagramScraper(username, password, target_username)
  scraper.scrape_instagram()
