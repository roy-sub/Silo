# Import necessary modules
from geopy.distance import geodesic
from geopy.geocoders import Nominatim
from constants import AI_SEARCH_LIMIT 

# Class to validate locations
class LocationValidator:
   
  # Constructor to initialize the geocoder 
  def __init__(self):
    self.loc = Nominatim(user_agent="GetLoc")

  # Method to get latitude and longitude of a location
  def get_latitude_longitude(self, location_name):
    location = self.loc.geocode(location_name)
    if location:
      return location.latitude, location.longitude
    else:
      return None, None

  # Method to validate locations within a certain radius of a point of interest (POI)
  def validate_locations(self, list_locations, poi_location, search_radius):
    poi_lat, poi_lon = self.get_latitude_longitude(poi_location)
    if poi_lat is None or poi_lon is None:
      return "Error: POI location not found."

    # Dictionary to store valid locations within the search radius
    valid_locations = {}
    for location in list_locations:
      # Get the latitude and longitude of the current location
      loc_lat, loc_lon = self.get_latitude_longitude(location)
      if loc_lat is None or loc_lon is None:
        continue

      # Calculate the distance between the POI and the current location
      distance = geodesic((poi_lat, poi_lon), (loc_lat, loc_lon)).kilometers

      # Check if the distance is within the search radius
      if distance < search_radius:
        valid_locations[distance] = location

    # Sort the valid locations by distance and return the top AI_SEARCH_LIMIT locations
    sorted_locations = [
        location for distance, location in sorted(valid_locations.items())
    ]
    return sorted_locations[:AI_SEARCH_LIMIT] 
