import re
import os
import time
from selenium import webdriver
from constants import CHROME_DRIVER_PATH
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException

class GoogleMapsScraper:
  def __init__(self):
    os.chmod(CHROME_DRIVER_PATH,0o755) 
    chrome_options = webdriver.ChromeOptions()
    self.driver = webdriver.Chrome(options=chrome_options) 

  def scrape_google_maps_titles_and_href(self, url, query):
    self.driver.get(url)

    divSideBar = self.driver.find_elements(By.CSS_SELECTOR, f'div[aria-label*="Results for {query}"]')
    divSideBar = divSideBar[0]

    keepScrolling=True
    start_time = time.time()

    while(keepScrolling):
        divSideBar.send_keys(Keys.PAGE_DOWN)
        time.sleep(0.5)
        divSideBar.send_keys(Keys.PAGE_DOWN)
        time.sleep(0.5)
        html =self.driver.find_element(By.TAG_NAME, "html").get_attribute('outerHTML')
        if(html.find("You've reached the end of the list.")!=-1 or time.time() - start_time > 60):
            keepScrolling=False

    elements = self.driver.find_elements(By.CLASS_NAME, "hfpxzc")

    data = []

    for element in elements:
      aria_label = element.get_attribute("aria-label")
      if aria_label:
          entry = {
              "title": aria_label,
              "href": element.get_attribute("href")
          }
          data.append(entry)

    return data
  
  def scrape_poi(self,title, url):
    self.driver.get(url)

    # 1. Scrape Title
    
    # 2. Scrape Average Rating

    try:
      avg_rating_element = self.driver.find_element(by=By.XPATH, value="//div[contains(@class, 'F7nice')]//span[contains(@aria-hidden, 'true')]")
      avg_rating = avg_rating_element.text
    except NoSuchElementException:
      avg_rating = ""
    
    # 3. Scrape Total Number of ratings
    
    try:
      total_reviews_element = self.driver.find_element(by=By.XPATH, value="//div[contains(@class, 'F7nice')]//span[contains(@aria-label, 'reviews')]")
      total_number_of_reviews = total_reviews_element.text
      total_number_of_reviews = total_number_of_reviews.replace('(', '').replace(')', '') 
    except NoSuchElementException:
      total_number_of_reviews = ""
    
    # 4. Scrape Description
    
    try:
      text_element = self.driver.find_element(by=By.XPATH, value="//div[contains(@class, 'PYvSYb')]")
      description = text_element.text
    except NoSuchElementException:
      description = ""
    
    # 5. Scrape Service Options
    
    try:
      service_option_elements = self.driver.find_elements(by=By.XPATH, value="//div[@class='E0DTEd']//div[contains(@class, 'LTs0Rc')]//div[@aria-hidden='true']")
      service_options = [option.text for option in service_option_elements] 
    except NoSuchElementException:
      service_options = ""
    
    # 6. Scrape Address
    
    try:
      address_button = self.driver.find_element(By.CSS_SELECTOR, 'button[aria-label^="Address"]')
      address = address_button.get_attribute('aria-label').split(': ')[1]
    except NoSuchElementException:
      address = ""
    
    # 7. Scrape Open Hours
    try:
      open_hours = self.driver.find_element(By.CSS_SELECTOR, '.t39EBf.GUrTXd').get_attribute('aria-label')
    except NoSuchElementException:
      open_hours = ""
    
    # 8. Scrape Website Link
    try:
      website = self.driver.find_element(By.CSS_SELECTOR, 'a[aria-label^="Website"]')
      website_link = website.get_attribute('href')
    except NoSuchElementException:
      website_link = ""
    
    # 9. Scrape Phone Number
    
    try:
      phone_button = self.driver.find_element(By.CSS_SELECTOR, 'button[aria-label^="Phone"]')
      phone_button_text = phone_button.text
      phone_number = phone_button_text.split('\n')[-1]
    except NoSuchElementException:
      phone_number = ""
    
    # 10. Scrape Reviews
    
    reviews = []
    
    try:
      review_elements = self.driver.find_elements(By.CSS_SELECTOR, '.DUGVrf [jslog*="track:click"]')
      review_texts = [element.get_attribute('aria-label') for element in review_elements]
    
      for review_text in review_texts:
          review_text = re.search('"([^"]*)"', review_text).group(1)
          reviews.append(review_text)
    
    except NoSuchElementException:
      pass
    
    try:
      review_elements = self.driver.find_elements(By.CSS_SELECTOR, '.wiI7pd')
      review_texts = [element.text for element in review_elements]
    
      for review_text in review_texts:
          reviews.append(review_text)
    except NoSuchElementException:
      pass

    result = {
        "url": url,
        "title": title,
        "avg_rating": avg_rating,
        "total_number_of_reviews": total_number_of_reviews,
        "description": description,
        "service_options": service_options,
        "address": address,
        "open_hours": open_hours,
        "website": website_link,
        "phone_number": phone_number,
        "reviews": reviews
    }

    return result

def main():
    # Create an instance of GoogleMapsScraper
    scraper = GoogleMapsScraper()
    data = []

    # Test data
    query = "Dentists in Zurich"
    url = "https://www.google.com/maps/search/Dentists+in+Zurich"

    # Scrape Google Maps titles and hrefs
    result = scraper.scrape_google_maps_titles_and_href(url, query)
    data.extend(result)

    filtered_data = {d['title']: d for d in data}
    filtered_list = list(filtered_data.values())
    # filtered_list = list(filtered_data.values())[:5]  # Limit to first 5 elements
    
    print(f"Number of Accounts to be scraped : {len(filtered_list)}")

    final_result = []

    for poi in filtered_list:

      title = poi['title']
      url = poi['href']

      scraper = GoogleMapsScraper()
      result = scraper.scrape_poi(title, url)
      
      print(f"result: {result}")
      
      final_result.append(result)

    print(f"\nResult Before Data Cleaning: {final_result}\n") 

    # Close the driver
    scraper.driver.quit()

    return final_result

if __name__ == "__main__":
    main()
