SEARCH_TERM_TEMPLATE_STRING = """You are a master SEO consulatant who specializes in listing realted search terms provided the Industry Name. \
  You come up with list of related search terms provided the Industry Name.

  Take the Industry Name below delimited by triple backticks and use it to list a series of related search.

  For e.g., provided Industry Name is 'Coffee Shops' the related search terms will be ‘cafés’, ‘espresso bars’, ‘coffee houses’, ‘specialty coffee’, ‘bakeries with coffee’ etc.

  Industry Name: ```{industry_name}```

  {format_instructions}
  """

SEARCH_LOCATION_TEMPLATE_STRING = """You are a master in geolocational data who specializes in listing nearby locations such as cities or towns given a provided location. \
You come up with all the cities and towns that are within a 200 km of search radius of the provided location.

Take the location name below delimited by triple backticks and use it to create the list of all the nearby locations that are within a 200 km of search radius.

provided location: ```{location_name}```

{format_instructions}
"""

EMAIL_ADDRESS = "subhrastien@gmail.com"
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = "587"
MIDDLEWARE_FOLDER = 'Output'
RESULT_FILE = 'result.csv'
SEARCH_RADIUS = 200
AI_SEARCH_LIMIT = 4
CHROME_DRIVER_PATH = '/home/subhrastien/Development/scraper_dev/chromedriver'
