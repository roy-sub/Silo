import requests
import time
import csv
import json
import os
from typing import List

def trigger_snapshot(urls):
    print("Triggering snapshot...")
    url = "https://api.brightdata.com/datasets/v3/trigger?dataset_id=gd_l1vikfch901nx3by4"
    headers = {
        "Authorization": "Bearer 50866a40-805b-46f4-b2ef-9baf0fb97222",
        "Content-Type": "application/json"
    }
    data = [{"url": url} for url in urls]
    response = requests.post(url, headers=headers, json=data)
    print(f"Response status code: {response.status_code}")
    return response.json()["snapshot_id"]

def fetch_and_process_snapshot(snapshot_id):
    # API endpoint and authorization header
    url = f'https://api.brightdata.com/datasets/v3/snapshot/{snapshot_id}?format=json'
    headers = {
        'Authorization': 'Bearer 50866a40-805b-46f4-b2ef-9baf0fb97222'  # Replace with your actual token
    }

    processed_items = []
    
    while True:
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            print(f"\nResponse status code: {response.status_code}")
            print(f"Response content: {data}")
            
            if isinstance(data, str) and data == "status":
                print("Snapshot is not ready yet. Waiting...")
                time.sleep(10)  # Wait for 10 seconds before trying again
                continue
            
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        processed_item = {
                            "User ID": item.get("id", ""),
                            "Username": item.get("account", ""),
                            "Full Name": item.get("full_name", ""),
                            "Category": item.get("business_category_name", ""),
                            "Followers": item.get("followers", ""),
                            "Following": item.get("following", ""),
                            "External URL": ", ".join(item.get("external_url", [])),
                            "Biography": item.get("biography", ""),
                            "Profile URL": item.get("profile_url", ""),
                            "Is business": item.get("is_business_account", ""),
                            "Is private": item.get("is_private", ""),
                            "Is verified": item.get("is_verified", ""),
                        }
                        processed_items.append(processed_item)
                break  # Exit the loop if we successfully processed the data
            else:
                print(f"Unexpected data format: {type(data)}")
                break
        
        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")
            break
    
    return processed_items
    
def read_csv(file_path: str) -> List[str]:
    urls = []
    with open(file_path, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            username = row['Username']
            urls.append(f"https://www.instagram.com/{username}/")
    return urls

def chunk_list(lst: List, chunk_size: int) -> List[List]:
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def save_json(data, folder: str, filename: str):
    os.makedirs(folder, exist_ok=True)
    file_path = os.path.join(folder, filename)
    with open(file_path, 'w') as jsonfile:
        json.dump(data, jsonfile, indent=2)

def _main_(file_path: str):
    
    urls = read_csv(file_path)
    url_batches = chunk_list(urls, 10)
    print(f"\n{url_batches}")
    
    snapshot_ids = []
    
    for index, batch in enumerate(url_batches, start=1):
        snapshot_id = trigger_snapshot(batch)
        snapshot_ids.append(snapshot_id)  # Store snapshot ID in the list
        print(f"Batch {index} - Snapshot ID: {snapshot_id}")
    
    # Print all snapshot IDs after processing all batches
    print(f"\nAll Snapshot IDs: {snapshot_ids}")
    
def main():
    file_path = "result_data/elowenfrostrpg.csv"
    snapshot_ids = ['s_m21wxybf3zsqw7by5', 's_m21wxzda1t9dststs5', 's_m21wy0cw28o8adb9zk', 's_m21wy1cmow7pzwa1h', 's_m21wy2dn1qtvv6llor', 's_m21wy3gu2l0jj1ohkh', 's_m21wy4k41vifwm91k0', 's_m21wy5jo1px09efh47', 's_m21wy6g31evm3nig6n', 's_m21wy7afgpyi53hyu', 's_m21wy8e6ie9l7hill', 's_m21wy9zk2grzu2c9q5', 's_m21wyaya9vjtxgmnu', 's_m21wyc8d2m4gk7isct', 's_m21wydlk1lwiacmvus', 's_m21wyez5f72h5y3fm', 's_m21wyfym1ej2sqws3u', 's_m21wyh2t2hgqwde4lf', 's_m21wyi241hevkztulx']
    output_folder = os.path.splitext(os.path.basename(file_path))[0]
    for index, snapshot_id in enumerate(snapshot_ids, start=1):
        processed_items = fetch_and_process_snapshot(snapshot_id)
        print(f"processed_items: {processed_items}")
        save_json(processed_items, output_folder, f"{index}.json")
        print(f"Saved results to {output_folder}/{index}.json")

if __name__ == "__main__":
    main()
