import os
import csv
import time
import json
import random
import instaloader
from urllib.parse import urlparse
from constants import login_user as INSTAGRAM_USER, login_password as INSTAGRAM_PASSWORD

class InstagramScraper:
    
    def __init__(self):
        self.L = instaloader.Instaloader()
        # self.login()

    def login(self):
        try:
            self.L.login(INSTAGRAM_USER, INSTAGRAM_PASSWORD)
            print("Successfully logged in to Instagram")
        except instaloader.exceptions.BadCredentialsException:
            print("Error: Invalid Instagram credentials")
        except Exception as e:
            print(f"Error logging in to Instagram: {str(e)}")
    
    def parse(self, path):
        account_links = []
        
        try:
            with open(path, 'r', newline='') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    if 'account_links' in row:
                        account_links.append(row['account_links'])
        except FileNotFoundError:
            print(f"Error: File not found at {path}")
        except csv.Error as e:
            print(f"Error reading CSV file: {e}")
        
        return account_links
    
    def extract_usernames(self, account_links):
        usernames = []
        for link in account_links:
            parsed_url = urlparse(link)
            # Extract username from path
            username = parsed_url.path.strip('/').split('/')[0]
            usernames.append(username)
        return usernames
    
    def get_followers_ids(self, username):
        # Create an instance of Instaloader
        L = instaloader.Instaloader()

        try:

            # Login to Instagram
            L.login(INSTAGRAM_USER, INSTAGRAM_PASSWORD)
            print(f"Login successful! Fetching followers for {username}")

            # Fetch the profile
            profile = instaloader.Profile.from_username(L.context, username)

            # Get followers
            followers = profile.get_followers()

            # Create result_data folder if it doesn't exist
            if not os.path.exists('result_data'):
                os.makedirs('result_data')

            # Create and write to CSV file
            with open(f'result_data/{username}.csv', 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(['Username', 'User ID'])  # Write header

                for follower in followers:
                    writer.writerow([follower.username, follower.userid])

            print(f"Followers data for {username} has been saved to result_data/{username}.csv")

        except instaloader.exceptions.InstaloaderException as e:
            print(f"An error occurred while processing {username}: {str(e)}")
            
    def get_instagram_profile_info(self, username, user_id, source):
        
        l = instaloader.Instaloader()
        
        # Generate a random sleep time between 10 and 20 seconds
        sleep_time = random.randint(10, 20)
        print(f"Sleeping for {sleep_time} seconds before fetching profile info.")
        
        # Sleep for the random period
        time.sleep(sleep_time)
    
        try:
            profile = instaloader.Profile.from_username(l.context, username)
            
            metadata = profile._metadata()
            category_name=metadata.get('category_name', 'No category found')

            info = {
                "Source profile (url)": f"https://www.instagram.com/{source}/",
                "User ID": user_id,
                "Username": username,
                "Full name": profile.full_name,
                "Followers (Amount)": profile.followers,
                "Following (Amount)": profile.followees,
                "External URL": profile.external_url,
                "Biography": profile.biography,
                "Profile URL": f"https://www.instagram.com/{username}/",
                "Is private": profile.is_private,
                "Is verified": profile.is_verified,
                "Category": category_name,
                "Is business account": profile.is_business_account
            }
            return info
        except instaloader.exceptions.ProfileNotExistsException:
            print(f"The profile {username} does not exist.")
            return None
        except Exception as e:
            print(f"An error occurred for {username}: {str(e)}")
            return None
    
    def process_files(self, input_folder_path, output_folder_path):
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)

        for filename in os.listdir(input_folder_path):
            if filename.endswith('.csv'):
                input_file_path = os.path.join(input_folder_path, filename)
                output_file_path = os.path.join(output_folder_path, f"{os.path.splitext(filename)[0]}.json")
                
                results = []
                
                with open(input_file_path, 'r', newline='', encoding='utf-8') as csvfile:
                    reader = csv.DictReader(csvfile)
                    for row in reader:
                        username = row['Username']
                        user_id = row['User ID']
                        source = filename[:-4] if filename.endswith('.csv') else filename
                        profile_info = self.get_instagram_profile_info(username, user_id, source)
                        
                        print(f"\nprofile_info: {profile_info}\n")
                        
                        if profile_info:
                            results.append(profile_info)
                
                with open(output_file_path, 'w', encoding='utf-8') as jsonfile:
                    json.dump(results, jsonfile, indent=2, ensure_ascii=False)


# Unit Testing

if __name__ == "__main__":
    
    scraper = InstagramScraper()
    
    # path = "instagram_base.csv"
    # aOurdemocracy@99ccount_links = scraper.parse(path)
    # print(f"number of account_links : {len(account_links)}\naccount_links: {account_links}")
    # usernames = scraper.extract_usernames(account_links)
    # print(f"number of account : {len(usernames)}\nusernames: {usernames}")
    # for username in usernames:
    #     scraper.get_followers_ids(username)

    input_folder_path = "result_data"
    output_folder_path = "final_result_data"
    scraper.process_files(input_folder_path, output_folder_path)
