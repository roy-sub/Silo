import os
import csv
import time
import json
import random
import instaloader
from urllib.parse import urlparse
from constants import login_user as INSTAGRAM_USER, login_password as INSTAGRAM_PASSWORD

class InstagramScraper:
    
    def parse(self, path):
        account_links = []
        
        try:
            with open(path, 'r', newline='') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    if 'account_links' in row:
                        account_links.append(row['account_links'])
        except FileNotFoundError:
            print(f"Error: File not found at {path}")
        except csv.Error as e:
            print(f"Error reading CSV file: {e}")
        
        return account_links
    
    def extract_usernames(self, account_links):
        usernames = []
        for link in account_links:
            parsed_url = urlparse(link)
            # Extract username from path
            username = parsed_url.path.strip('/').split('/')[0]
            usernames.append(username)
        return usernames
    
    def get_followers_ids(self, username):
        # Create an instance of Instaloader
        L = instaloader.Instaloader()

        try:

            # Login to Instagram
            L.login(INSTAGRAM_USER, INSTAGRAM_PASSWORD)
            print(f"Login successful! Fetching followers for {username}")

            # Fetch the profile
            profile = instaloader.Profile.from_username(L.context, username)

            # Get followers
            followers = profile.get_followers()

            # Create result_data folder if it doesn't exist
            if not os.path.exists('result_data'):
                os.makedirs('result_data')

            # Create and write to CSV file
            with open(f'result_data/{username}.csv', 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(['Username', 'User ID'])  # Write header

                for follower in followers:
                    writer.writerow([follower.username, follower.userid])

            print(f"Followers data for {username} has been saved to result_data/{username}.csv")

        except instaloader.exceptions.InstaloaderException as e:
            print(f"An error occurred while processing {username}: {str(e)}")


# Unit Testing

if __name__ == "__main__":
    
    scraper = InstagramScraper()
    base_path = "instagram_base.csv"
    account_links = scraper.parse(base_path)
    usernames = scraper.extract_usernames(account_links)
    for username in usernames:
        scraper.get_followers_ids(username)
