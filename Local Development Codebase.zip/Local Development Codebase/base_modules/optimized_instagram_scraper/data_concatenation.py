import json
import csv
import os
from typing import List, Dict

def read_json_files(folder_path: str) -> List[Dict]:
    all_data = []
    for filename in os.listdir(folder_path):
        if filename.endswith('.json'):
            with open(os.path.join(folder_path, filename), 'r') as file:
                data = json.load(file)
                all_data.extend(data)
    return all_data

def add_source_profile(data: List[Dict], source_profile: str) -> List[Dict]:
    for item in data:
        item['Source profile'] = source_profile
    return data

def write_csv(data: List[Dict], output_path: str):
    if not data:
        print("No data to write to CSV.")
        return

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    fieldnames = list(data[0].keys())
    
    with open(output_path, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for row in data:
            writer.writerow(row)

def main():
    profile_folder = "elowenfrostrpg"
    input_folder = f"profile_data/{profile_folder}"
    output_folder = "deliverable"
    output_filename = f"{profile_folder}.csv"
    source_profile = f"https://www.instagram.com/{profile_folder}"

    # Read all JSON files
    all_data = read_json_files(input_folder)

    # Add source profile to each item
    all_data = add_source_profile(all_data, source_profile)

    # Write to CSV
    output_path = os.path.join(output_folder, output_filename)
    write_csv(all_data, output_path)

    print(f"CSV file has been created at: {output_path}")

if __name__ == "__main__":
    main()